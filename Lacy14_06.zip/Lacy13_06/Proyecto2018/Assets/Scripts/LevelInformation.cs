﻿using System.Collections;
using UnityEngine;
	
[System.Serializable]
public class LevelInformation{
	// Here will be saved the level information
	public string LevelName;   // Name of the level the player will transition to

}
