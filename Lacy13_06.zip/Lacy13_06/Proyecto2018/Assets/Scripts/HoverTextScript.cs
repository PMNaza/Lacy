﻿using UnityEngine;
using System.Collections;

public class HoverTextScript : MonoBehaviour {
	// Use this for initialization
	void Start () {
		GetComponent<MeshRenderer> ().sortingLayerName = "HoverLayer";
	
	}
}
