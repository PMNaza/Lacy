﻿using UnityEngine;
using System.Collections;

[System.Serializable]
public class Dialogue {
	// This is the information needed to start a dialogue
	public string name;  	// NPC name
	public string[] sentences;	// What this NPC has to say


}
