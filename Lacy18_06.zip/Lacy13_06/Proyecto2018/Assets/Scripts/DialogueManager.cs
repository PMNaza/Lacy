﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using UnityEngine.UI;

public class clsSentences {
	public string sentencia;
	public string deQuien;
}

public class DialogueManager : MonoBehaviour {
	
	private Queue<clsSentences> Sentences;   // Holds all the sentences to show
	public Animator DialogueAnim;
	public Animator DialogueTextAnim;

	public Text NameText;
	public Text DialogueText;
	bool IsFritz = false;


	// Use this for initialization
	void Start () {
		Sentences = new Queue<clsSentences> ();
	}

	// Update is called once per frame
	void Update () {

	}

	public void StartDialogue(Dialogue dialogue)
	{
		Debug.Log ("Starting dialogue");
		DialogueAnim.SetInteger ("DialogueBox", 2);
		Sentences.Clear ();
		foreach (string sentence in dialogue.sentences) { // Brings forward all the words from first sentence the NPC has to say
			clsSentences s = new clsSentences();
			s.sentencia = sentence;
			s.deQuien = "NPC";
			Sentences.Enqueue (s);
			Debug.Log ("NPC Line's");
		}
		/*foreach (string sentence in dialogue.PlayerSpeech) { // Brings forward all the words from first sentence the NPC has to say
			clsSentences s = new clsSentences();
			s.sentencia = sentence;
			s.deQuien = "Fritz";
			Sentences.Enqueue (s);
			Debug.Log ("Fritz line's");
		}*/

	    DisplayNextSentence ();  // Once the sentence is finished, the player can call the next one
	}

	public void DisplayNextSentence()
	{
		if (Sentences.Count == 0)   // If theres no more sentences to show, end the dialogue
		{
			Debug.Log ("No sentences to show");
			EndDialogue ();
			return;
		}

		Debug.Log("next sentence:");
		clsSentences s = Sentences.Dequeue();
		StopAllCoroutines ();
		DialogueText.text = s.sentencia;
		if (IsFritz == false)
		{
			Debug.Log (IsFritz);
			NameText.text = s.deQuien;	
			IsFritz = true;
		}
		else
		{
			Debug.Log ("Fritz's turn " + IsFritz);
			NameText.text = "Fritz";
			IsFritz = false;
		}
		StartCoroutine (TypeSentence (s));
		//DialogueText.text = sentence;
	}
	 
	IEnumerator TypeSentence(clsSentences s)
	{
		DialogueText.text = "";
		//NameText.text = s.deQuien;

		foreach (char letter in s.sentencia.ToCharArray()) { //Grabs each sentence's char and add's them one by one
			DialogueText.text += letter;
			yield return null;
		}
	}

	public void EndDialogue()
	{
		DialogueAnim.SetInteger ("DialogueBox", 3);
		//DialogueAnim.SetInteger ("DialogueBox", 1);
		Debug.Log("End Conversation.");
	}
}
