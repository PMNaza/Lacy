﻿using UnityEngine;
using System.Collections;

public class PlayerInteract : MonoBehaviour {
	GameObject currentInterObj = null;  // The gameObject that is in range of the player
	InteractionController currentInterObjScript; // Scripts that all Interactables have
	public GameObject HoverText; // GameObject where the text will be displayed
	public Animator FadeAnim;  //This is the animator that controls the Fade_In & Fade_Out animations
	Object TemporaryHover;  // Its is created a copy of the hover image for its destruction later
	int i = 1;
	void Update()
	{
		if (i == 1)
		{
			if (Input.GetButtonDown ("Interact") && currentInterObj) {  // if the player pressed the designated key and the player is near an interactable
				if (currentInterObjScript.NPC) {  // If the other object is a NPC
					currentInterObjScript.StartDialogue ();
					i = 0;
				}
			}
			if (Input.GetButtonDown ("Interact") && currentInterObj) {	// if the player pressed the designated key and the player is near an interactable
				if (currentInterObjScript.Item) { // If the other object is an Item
					currentInterObjScript.PickItem (currentInterObj);
					OnExitHover ();
					i = 0;
				}
			}
			if (currentInterObj){
				if (currentInterObjScript.Door){
					currentInterObjScript.RoomTransition (FadeAnim);
					i = 0;				}
			}

		}
	}

	void OnTriggerEnter2D(Collider2D other)
	{
		GetTypeOfCollider (other);
		if (currentInterObjScript.Item) {
			OnEnterHover (other);
		}


	}
	void OnTriggerExit2D(Collider2D other)
	{
		// If the object is the same as on OntriggerEnter2D, empty currentInterObj
		if (other.CompareTag("NPC") || other.CompareTag("Item") || other.CompareTag("Door"))   
		{
			if (other.gameObject == currentInterObj)
				{
				currentInterObj = null;
				OnExitHover();
				i = 1;
				}
		}
	}
	private void GetTypeOfCollider(Collider2D other)
	{
		if (other.CompareTag ("NPC"))   // If its a NPC save its info in currentInterObj
		{
			Debug.Log (other.name);
			currentInterObj = other.gameObject;
			currentInterObjScript = currentInterObj.GetComponent<InteractionController> ();  // Gets the NPC's script
		}
		if (other.CompareTag ("Item")) 
		{
			currentInterObj = other.gameObject;
			currentInterObjScript = currentInterObj.GetComponent<InteractionController> (); // Gets the Item's script
		}
		if (other.CompareTag ("Door"))
		{
			currentInterObj = other.gameObject;
			currentInterObjScript = currentInterObj.GetComponent<InteractionController> ();
		}

	}
	private void OnEnterHover(Collider2D other)  // Shows the message
	{
		Debug.Log ("Show hovering text");
		HoverText.GetComponent<TextMesh> ().text = "Agarrar";  
		TemporaryHover = Instantiate (HoverText, new Vector3 (other.transform.position.x, other.transform.position.y + 0.5f,0), other.transform.rotation);  //Creates a clone of the text so it can be destroyed later
	}
	private void OnExitHover()  // Destroy the hover message
	{
		Debug.Log ("Exit Hover");
		Destroy (TemporaryHover); //Destroys the clone
	}


	//{}
}
