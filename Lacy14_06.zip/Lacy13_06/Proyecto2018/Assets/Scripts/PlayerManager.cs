﻿using UnityEngine;
using System.Collections;
using UnityEngine.UI;

public class PlayerManager : MonoBehaviour {
	Animator anim;
	public float speed;
	private bool CanLeft, CanRight, CanUp, CanDown;
	GameObject NewText;
	Text MyText;
	// Use this for initialization
	void Start ()
	{
		anim = GetComponent<Animator> (); 
		CanUp = true;
		CanRight = true;
		CanLeft = true;
		CanDown = true;
	}
	
	// Update is called once per frame
	void Update ()
	{
		Walk ();

	}
	public bool GetBoolean(int i){
		if (i != 1 || i != 2 || i != 3 || i != 4) {
			return Debug.LogError();
		} 
		else 
		{
			switch (i) {
			case 1:
				return CanLeft;
				break;
			case 2:
				return CanRight;
				break;
			case 3:
				return CanUp;
				break;
			case 4:
				return CanDown;
				break;
			}
		}
			
	}
	void OnCollisionEnter2D(Collision2D coll) 
	{
		HitsCollider (coll);			
	}
	//{}


	public void HitsCollider(Collision2D coll)
	{
		// Stops movement from designated Key when player hits the collider
		if (coll.gameObject.tag == "Object" && Input.GetKey(KeyCode.LeftArrow)) 
		{
			CanLeft = false;
			Debug.Log ("CanLeft");
		}
		if (coll.gameObject.tag == "Object" && Input.GetKey (KeyCode.RightArrow))
		{
			CanRight = false;
			Debug.Log ("CanRight");
		}
		if (coll.gameObject.tag == "Object" && Input.GetKey (KeyCode.UpArrow))
		{
			CanUp = false;
			Debug.Log ("CanUp");
		}
		if (coll.gameObject.tag == "Object" && Input.GetKey (KeyCode.DownArrow))
		{
			CanDown = false;
			Debug.Log ("CanDown");
		}
	}

	void OnCollisionExit2D(Collision2D coll)
	{
		//Allows movement if player leaves wall collider
		if (coll.gameObject.tag == "Object") 
		{
			CanLeft = true;
			CanUp = true;
			CanDown = true;
			CanRight = true;
			Debug.Log ("InHouse");
		}
	}
	public void Walk()
	{
		
		// Changing state from idle to walking
		if (Input.GetKey (KeyCode.UpArrow)) {
			anim.SetInteger ("State", 8);
			if (CanUp)
				MoveUp ();
		} else if (Input.GetKey (KeyCode.DownArrow)) {
			anim.SetInteger ("State", 2);
			if (CanDown)
				MoveDown ();
		} else if (Input.GetKey (KeyCode.LeftArrow)) {
			anim.SetInteger ("State", 4);
			if (CanLeft)
				MoveLeft ();
		} else if (Input.GetKey (KeyCode.RightArrow)) {
			anim.SetInteger ("State", 6);
			if (CanRight)
				MoveRight ();
		} else {						
			// Changin state from walking to idle
			anim.SetInteger ("State", 5);
		}

	}
	public void MoveUp()
	{
		float vertical = Input.GetAxis ("Vertical");
		float horizontal = Input.GetAxis ("Horizontal");
		var move = new Vector3 (horizontal, vertical, 0);
		anim.SetInteger ("State", 8);
		vertical = Input.GetAxis ("Vertical");
		horizontal = Input.GetAxis ("Horizontal");
		move = new Vector3 (horizontal, vertical, 0);
		transform.position += move * speed * Time.deltaTime;
	}
	public void MoveDown()
	{
		float vertical = Input.GetAxis ("Vertical");
		float horizontal = Input.GetAxis ("Horizontal");
		var move = new Vector3 (horizontal, vertical, 0);
		anim.SetInteger ("State", 2);
		horizontal = Input.GetAxis ("Horizontal");
		vertical = Input.GetAxis ("Vertical");
		move = new Vector3 (horizontal, vertical, 0);
		transform.position += move * speed * Time.deltaTime;
	}
	public void MoveLeft() 
	{
	    float vertical = Input.GetAxis ("Vertical");
		float horizontal = Input.GetAxis ("Horizontal");
		var move = new Vector3 (horizontal, vertical, 0);
		anim.SetInteger ("State", 4);
		horizontal = Input.GetAxis ("Horizontal");
		vertical = Input.GetAxis ("Vertical");
		move = new Vector3 (horizontal, vertical, 0);
		transform.position += move * speed * Time.deltaTime;
	}
	public void MoveRight()
	{
		float vertical = Input.GetAxis ("Vertical");
		float horizontal = Input.GetAxis ("Horizontal");
		var move = new Vector3 (horizontal, vertical, 0);
		anim.SetInteger ("State", 6);
		horizontal = Input.GetAxis ("Horizontal");
		vertical = Input.GetAxis ("Vertical");
		move = new Vector3 (horizontal, vertical, 0);
		transform.position += move * speed * Time.deltaTime;
	}



}

//{}