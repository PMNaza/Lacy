﻿using UnityEngine;
using System.Collections;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class InteractionController : MonoBehaviour {
	public bool NPC;  // if true the object will open up a dialoge
	public bool Item;  // defines this game object as an item (if true)
	public bool Door;  // if true the player will move to the next room

	public LevelInformation LevelInfo; //information about the level
	public Dialogue dialogue;  // information about the NPC



	void Start()
	{

	}
	public void StartDialogue()
	{
		Debug.Log ("Dialogue Manager Start");
		FindObjectOfType<DialogueManager> ().StartDialogue (dialogue);   // Calls StartDialogue function from DialogueManager Script
	}
	public void PickItem(GameObject Item)
	{
		Debug.Log ("Pick Item");
		Item.SetActive (false);  //The item does poof
	}
	public void RoomTransition(Animator anim)
	{
		anim.SetTrigger ("FadeOut");
	}
	public void OnFadeComplete()
	{
		SceneManager.LoadScene ("LevelName");
	}


		


	//{}

	
}
